package com.example.flutter_connectivity_service

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
